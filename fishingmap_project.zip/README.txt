FishingMap project files placeholder.
You can add full project files here.